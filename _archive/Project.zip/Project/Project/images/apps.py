from django.apps import AppConfig


class ImagesConfig(AppConfig):
    default_auto_field: str = "django.db.models.AutoField"
    name = "Project.images"
